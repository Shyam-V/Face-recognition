from django.shortcuts import render, redirect
from django.http import HttpResponse
from collections import defaultdict
import os
import shutil
from subprocess import run,PIPE
import sys
a=0
data=defaultdict()
data['ritesh']='lalu'
def home(request):
    for key in data.keys():
        if key == '' or data[key]== '':
            del data[key]
    return render(request,'index.html')
def login(request):
    if request.method=="POST":
        if request.POST['Username'] in data and request.POST['Password']==data[request.POST['Username']]:
            return redirect('/mainpage')
        else:
            return redirect('/signup')
    else:
        return redirect('/mainpage')

def signup(request):
    return render(request,'signup.html')
def mainpage(request):
    return render(request, 'mainpage.html')
def register(request):
    if request.method=="POST":
        print(request.POST)
        if request.POST['Password']==request.POST['Confirm_password']:
            data[request.POST['Username']]=request.POST['Password']
            return render(request, 'register.html')
        else:
            return HttpResponse("Password Not Matched")

def dataset(request):
    if request.method == 'POST':
        for afile in request.FILES.getlist('files'):
            handle_uploaded_file(afile, str(afile),str(request.POST['foldername']))
        return HttpResponse("Successful")

    return HttpResponse("Failed")

def handle_uploaded_file(file, filename,foldername):
    if not os.path.exists(os.path.join("C:/Users/singh/Desktop/dataset/",foldername,"")):
        os.mkdir(os.path.join("C:/Users/singh/Desktop/dataset/",foldername,""))

    with open(os.path.join('C:/Users/singh/Desktop/dataset/',foldername,"") + filename, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)

def delete(request):
    foldername=str(request.POST['foldername'])
    if os.path.exists(os.path.join("C:/Users/singh/Desktop/dataset/", foldername, "")):
        path = os.path.join("C:/Users/singh/Desktop/dataset/", foldername)
        shutil.rmtree(path)
        return HttpResponse("User Account Deleted")
    else:
        return HttpResponse("No User Found ")
def control(request):
    global a
    a = 1 - a
    print(a)
    if a == 1:
        return  HttpResponse("USER MODE SWITCHED")
    else:
        file = os.startfile(r'C:\Users\singh\Desktop\output.py')
        return  HttpResponse("THEFT MODE SWITCHED")





